import React from 'react';
import {AbsoluteFill, Audio, interpolate, Sequence, useCurrentFrame, useVideoConfig, staticFile} from 'remotion';

const clamp = {extrapolateLeft:'clamp' as const, extrapolateRight:'clamp' as const};
const Caption: React.FC<{children:string}> = ({children}) => (
  <div style={{position:'absolute',bottom:45,left:70,right:70,textAlign:'center',fontFamily:'Arial,sans-serif',
    fontWeight:900,fontSize:31,color:'#fff',textShadow:'0 3px 5px #000, 2px 2px #000',
    background:'rgba(0,0,0,.48)',padding:'14px 18px',borderRadius:10,letterSpacing:'.3px'}}>{children}</div>
);

const Boy: React.FC<{x:number; walking:boolean; scared?:boolean}> = ({x,walking,scared}) => {
  const f=useCurrentFrame();
  const bob=walking?Math.sin(f*.32)*5:Math.sin(f*.08)*1.5;
  const swing=walking?Math.sin(f*.32)*24:0;
  const headTurn=scared?interpolate(f,[0,20,30],[0,-16,-16],clamp):0;
  return <g transform={`translate(${x} ${bob})`}>
    <ellipse cx="0" cy="186" rx="39" ry="9" fill="#05090d" opacity=".55"/>
    <g strokeLinecap="round" strokeWidth="17" fill="none">
      <path d={`M-12 124 L${-17+swing*.65} 180`} stroke="#1b2a3c"/>
      <path d={`M12 124 L${17-swing*.65} 180`} stroke="#1b2a3c"/>
    </g>
    <path d="M-31 55 Q-40 66 -34 125 Q0 139 34 125 Q40 66 31 55Z" fill="#344d68" stroke="#172435" strokeWidth="4"/>
    <path d={`M-27 66 L${-49-swing*.3} 105`} stroke="#344d68" strokeWidth="14" strokeLinecap="round"/>
    <path d={`M27 66 L${49+swing*.3} 105`} stroke="#344d68" strokeWidth="14" strokeLinecap="round"/>
    <g transform={`rotate(${headTurn} 0 30)`}>
      <ellipse cx="0" cy="26" rx="25" ry="31" fill="#d2a17e" stroke="#3a2925" strokeWidth="3"/>
      <path d="M-24 19 Q-23 -10 2 -7 Q24 -7 25 17 Q9 4 -4 10 Q-16 9 -24 19" fill="#302522"/>
      <circle cx="-9" cy="28" r="2.7" fill="#191617"/><circle cx="9" cy="28" r="2.7" fill="#191617"/>
      <path d="M-6 43 Q0 46 6 43" stroke="#713f3a" fill="none" strokeWidth="2"/>
    </g>
  </g>;
};

const Cabin: React.FC = () => {
 const f=useCurrentFrame();
 const flicker= .65 + Math.sin(f*.27)*.15 + Math.sin(f*.91)*.08;
 return <g>
  <rect x="720" y="300" width="440" height="230" fill="#654632" stroke="#241d1b" strokeWidth="7"/>
  {Array.from({length:8}).map((_,i)=><line key={i} x1="724" y1={326+i*26} x2="1156" y2={326+i*26} stroke="#8a6044" strokeWidth="3"/>)}
  <path d="M680 306 L940 155 L1200 306Z" fill="#292d39" stroke="#151a25" strokeWidth="8"/>
  <rect x="760" y="350" width="125" height="92" fill={`rgba(240,170,72,${flicker})`} stroke="#d5c6a1" strokeWidth="9"/>
  <path d="M820 350 V442 M760 396 H885" stroke="#2a2b31" strokeWidth="7"/>
  <rect x="1010" y="370" width="110" height="160" fill="#2c211e" stroke="#151313" strokeWidth="5"/>
  <circle cx="1097" cy="450" r="5" fill="#d9b06c"/>
 </g>;
};

const Shadow: React.FC = () => {
 const f=useCurrentFrame();
 const opacity=interpolate(f,[95,125,155,205],[0,.95,.95,0],clamp);
 const sway=Math.sin(f*.12)*7;
 return <g opacity={opacity} transform={`translate(${sway} 0)`}>
   <ellipse cx="824" cy="373" rx="29" ry="34" fill="#030509"/>
   <path d="M790 410 Q824 393 858 410 L880 566 L768 566Z" fill="#030509"/>
   <circle cx="813" cy="374" r="4" fill="#e7e4d8"/><circle cx="835" cy="374" r="4" fill="#e7e4d8"/>
 </g>;
};

const Scene: React.FC = () => {
 const f=useCurrentFrame();
 const {fps}=useVideoConfig();
 const x=interpolate(f,[0,110,145,864],[150,600,600,600],clamp);
 const walk=f<110;
 const night=interpolate(f,[0,90,110,864],[0,0,1,1],clamp);
 const captions=[
  [0,120,'ОН ПРИЕХАЛ В СТАРЫЙ ДОМ НА ВЫХОДНЫЕ…'],
  [120,220,'МЕСТНЫЕ ГОВОРИЛИ, ЧТО ПОСЛЕ ПОЛУНОЧИ ТАМ НЕЛЬЗЯ ГАСИТЬ СВЕТ.'],
  [220,330,'НО ОН НЕ ВЕРИЛ В СТАРЫЕ СУЕВЕРИЯ.'],
  [330,440,'ПОКА В ОКНЕ НЕ ПОЯВИЛАСЬ ЧЬЯ-ТО ФИГУРА.'],
  [440,555,'ОН ЗАМЕР. ФИГУРА ТОЖЕ НЕ ДВИГАЛАСЬ.'],
  [555,680,'А ПОТОМ ОН УСЛЫШАЛ ШЁПОТ ПРЯМО ЗА СПИНОЙ…'],
  [680,864,'«ТЫ ЗАБЫЛ ЗАКРЫТЬ ДВЕРЬ».']
 ] as [number,number,string][];
 const cap=captions.find(([a,b])=>f>=a&&f<b)?.[2]||'';
 return <AbsoluteFill style={{background:'#101827',overflow:'hidden'}}>
  <svg width="100%" height="100%" viewBox="0 0 1280 720">
   <defs><linearGradient id="sky" x2="0" y2="1"><stop stopColor="#18283c"/><stop offset="1" stopColor="#4a463e"/></linearGradient>
    <radialGradient id="moon"><stop stopColor="#e1e0cf"/><stop offset="1" stopColor="#8b978f"/></radialGradient></defs>
   <rect width="1280" height="720" fill="url(#sky)"/>
   <circle cx="1040" cy="105" r="48" fill="url(#moon)" opacity=".8"/>
   {Array.from({length:20}).map((_,i)=><path key={i} d={`M${i*72-30} 470 l35 -${90+(i*37)%100} l35 ${90+(i*37)%100}Z`} fill="#0d2426"/>)}
   <rect y="470" width="1280" height="250" fill="#1b302b"/>
   <path d="M0 585 Q450 530 1280 580 L1280 720 L0 720Z" fill="#28352d"/>
   <Cabin/>
   <g opacity=".9"><path d="M0 430 Q90 340 180 440 Q230 360 310 455" fill="none" stroke="#091d1d" strokeWidth="42"/></g>
   <Boy x={x} walking={walk} scared={f>540}/>
   <Shadow/>
   <rect width="1280" height="720" fill="#03050b" opacity={night*.22}/>
   <rect x="4" y="4" width="1272" height="712" fill="none" stroke="rgba(0,0,0,.35)" strokeWidth="10"/>
  </svg>
  {cap && <Caption>{cap}</Caption>}
 </AbsoluteFill>;
};

export const MysteryShort: React.FC = () => {
 const f=useCurrentFrame();
 const fade=interpolate(f,[0,20,830,864],[0,1,1,0],clamp);
 return <AbsoluteFill style={{background:'#080b12',opacity:fade}}>
  <Scene/>
 </AbsoluteFill>;
};
