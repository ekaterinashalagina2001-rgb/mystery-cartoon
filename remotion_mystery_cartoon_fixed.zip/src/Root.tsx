import React from 'react';
import { Composition } from 'remotion';
import { MysteryShort } from './MysteryShort';

export const RemotionRoot: React.FC = () => (
  <Composition
    id="MysteryShort"
    component={MysteryShort}
    durationInFrames={24 * 36}
    fps={24}
    width={1280}
    height={720}
  />
);
